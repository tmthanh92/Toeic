var L10n = { 
  group: {
    key: 'value'
  }
};
